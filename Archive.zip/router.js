
const url = require('url');
// импорт обработчика маршрутов
const userRoutes = require('./userRoutes/userRoutes');
// функция обработки запросов
const routeHandler = function(request, response) {
    const parsedUrl = url.parse(request.url, true);
    const path = parsedUrl.pathname;
    if (path === '/users' || path.startsWith('/users/')) {
        userRoutes(request, response);
    } else {
        response.setHeader('Content-Type', 'application/json');
        response.writeHead(404); // Ошибка 404 page not found
        response.end(JSON.stringify({message: 'Route not found'}));
    }
};
module.exports = routeHandler; // экспорт обработчика маршрутов

