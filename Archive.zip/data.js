// создание массива для хранения пользователей
let users = [];
let currentID = 1;

module.exports = {
    getUsers: () => users,
    createUser: (user) => {
        user.id = currentID++;
        users.push(user);
    },
    updateUser: (id, updateData) => {
        const userIndex = users.findIndex(function(user) {user.id === id});
        if (userIndex !== -1) {
            users[userIndex] = {...users[userIndex], updateData};
            return users[userIndex];
        }
        return null;
    },
    deleteUser: (id) => {
        const userIndex = users.findIndex(function(user) {user.id === id});
        if (userIndex !== -1) {
            users.splice(userIndex, 1);
            return true;
        }
        return false;
    },
    getUserByID: (id) => users.find((user) => {user.id === id})
};

