
const http = require('http');
// импорт обработчика маршрутов
const routeHandler = require('./router');
// создание http сервера
const server = http.createServer(routeHandler);
// starts a simple http server locally on port 3000
const PORT = 3000;
server.listen(PORT, () => {
    console.log(`Server running on port: ${PORT}`);
});

