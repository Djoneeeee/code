
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database("mydatabase.db");
db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    age INTEGER NOT NULL
)`); // создание таблицы с колонками id, name, age

module.exports = {
    // получить список users
    async getUsers() {
        try {
            const users = await new Promise(function(resolve, reject) {
                db.all('SELECT * FROM users', [], (error, rows) => {
                    if (error) {
                        reject(error);
                    } else {
                        resolve(rows);
                    }
                });
            });
            return users;
        } catch (error) {
            return null;
        }
    },
    // создать user по значениям name и age
    async createUser(user) {
        const userIndex = await new Promise(function(resolve, reject) {
            db.run('INSERT INTO users (name, age) VALUES (?, ?)', [user.name, user.age], function(error) {
                if (error) {
                    reject(error);
                } else {
                    resolve(this.userIndex);
                }
            });
        });
        return {id: userIndex, ...user};
    },
    // обновить name, age у user
    async updateUser(id, updateData) {
        const changes = await new Promise(function(resolve, reject) {
            db.run('UPDATE users SET name = ?, age = ?, WHERE id = ?', [updateData.name, updateData.age, id], (error) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(changes);
                }
            });
        });
        if (changes === 0) {
            return null;
        }
        return this.getUserByID(id);
    },
    // удалить user по id
    async deleteUser(id) {
        const changes = await new Promise(function(resolve, reject) {
            db.run('DELETE FROM users WHERE id = ?', [id], function(error, row) {
                if (error) {
                    reject(error);
                } else {
                    resolve(this.changes);
                }
            });
        });
        return changes > 0;
    },
    // получить user по id
    async getUserByID(id) {
        const user = await new Promise(function(resolve, reject) {
            db.get('SELECT * FROM users WHERE id = ?', [id], (error, row) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(row);
                }
            });
        });
        return user;
    }
};

