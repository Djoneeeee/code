//const data = require('../data');
const data = require('../sql3-data.js');

module.exports = function(request, response) {
    const id = parseInt(request.url.split('/')[2]);
    let body = "";
    request.on('data', chunk => {
        body += chunk;
    });
    request.on('end', async () => {
        // создание поля для ввода данных о пользователе
        const parsedBody = new URLSearchParams(body);
        const updatedData = {};
        parsedBody.forEach(function(value, key) {
            updatedData[key] = key === 'age' ? parseInt(value) : value;
        }); 
        //const updatedUser = data.updateUser(id, updatedData);
        const updatedUser = await data.updateUser(id, updatedData);
        if (updatedUser) {
            response.writeHead(200);    // веб-сервер успешно обработал запрос и предоставил пользователю запрошенный контент
            response.end(JSON.stringify(updatedUser));
        } else {
            response.writeHead(400);    // неправильный запрос  
            response.end(JSON.stringify({message: 'User not found'}));
        }
    });
};

