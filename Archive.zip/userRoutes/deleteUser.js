//const data = require('../data');
const data = require('../sql3-data.js');

module.exports = async function(request, response) {
    const id = parseInt(request.url.split('/')[2]);
    //const isDelete = data.deleteUser(id);
    const isDelete = await data.deleteUser(id);
    if (isDelete) {
        response.writeHead(204);    // сервер успешно обработал запрос, но в ответе были переданы только заголовки без тела сообщения
        response.end();
    } else {
        response.writeHead(404); // Ошибка 404 page not found
        response.end(JSON.stringify({message: 'User not found'}));
    }
};
