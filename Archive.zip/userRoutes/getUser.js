//const data = require('../data');
const data = require('../sql3-data.js');

module.exports = async function(request, response) {
    const id = parseInt(request.url.split('/')[2]);
    //const user = data.getUserByID(id);
    const user = await data.getUserByID(id);
    if (user) {
        response.writeHead(200);    // веб-сервер успешно обработал запрос и предоставил пользователю запрошенный контент
        response.end(JSON.stringify(user));
    } else {
        response.writeHead(404); // Ошибка 404 page not found
        response.end(JSON.stringify({message: 'User not found'}));
    }
};




