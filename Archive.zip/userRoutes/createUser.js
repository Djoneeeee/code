//const data = require('../data');
const data = require('../sql3-data.js');

module.exports = (request, response) => {
    let body = "";
    request.on('data', chunk => {
        body += chunk;
    });
    request.on('end', async () => {
        // создание поля для ввода данных о пользователе
        const parsedBody = new URLSearchParams(body);
        const name = parsedBody.get('name');
        const age = parsedBody.get('age');
        if (name && age) {
            const user = {name, age: parseInt(age)};
            //data.createUser(user);
            const createdUser = await data.createUser(user);         
            response.writeHead(201);    // запрос выполнен успешно и привёл к созданию ресурса
            //response.end(JSON.stringify(user));
            response.end(JSON.stringify(createdUser));
        } else {
            response.writeHead(400);    // неправильный запрос  
            response.end(JSON.stringify({message: 'Name or age are required'}));
        }
    });
};
