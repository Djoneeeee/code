const url = require('url');
// импорт обработчика маршрутов
const listUsers = require('./listUsers');
const createUser = require('./createUser');
const getUser = require('./getUser.js');
const updateUser = require('./updateUser');
const deleteUser = require('./deleteUser');

// функция обработки запросов
const userRoutes = function(request, response) {
    const parsedUrl = url.parse(request.url, true);
    const method = request.method;
    const path = parsedUrl.pathname;
    response.setHeader('Content-Type', 'application/json');
    if (path === '/users' && method === 'GET') {
        listUsers(request, response);   // получения информации о пользователях
    } else if (path === '/users' && method === 'POST') {
        createUser(request, response);  // создание пользователя
    } else if (path.startsWith('/users/') && method === 'GET') {
        getUser(request, response); // получения информации о пользователе
    } else if (path.startsWith('/users/') && method === 'PUT') {
        updateUser(request, response); // обновление информации о пользователе
    } else if (path.startsWith('/users/') && method === 'DELETE') {
        deleteUser(request, response); // удаление информации о пользователе
    } else {
        response.writeHead(404);
        response.end(JSON.stringify({message: 'Route not found in users'}));
    }
};
module.exports = userRoutes;
